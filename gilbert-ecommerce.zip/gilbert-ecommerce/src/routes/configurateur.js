const router = require('express').Router();
const ctrl = require('../controllers/configurateurController');
const { requireAdmin } = require('../middleware/auth');
const { uploadLogo } = require('../middleware/upload');

router.post('/order', uploadLogo, ctrl.submitOrder);
router.get('/orders', requireAdmin, ctrl.getAll);
router.patch('/orders/:id/bat', requireAdmin, ctrl.updateBat);

module.exports = router;
