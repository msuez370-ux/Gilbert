const db = require('../config/db');
const { sendOrderConfirmation } = require('../services/emailService');

function generateRef() {
  return 'JV-' + Date.now().toString(36).toUpperCase();
}

exports.create = async (req, res) => {
  const { client, items, payment_method, payment_id } = req.body;
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const total = items.reduce((sum, i) => sum + i.prix_unitaire * i.quantite, 0);
    const ref = generateRef();
    const [order] = await conn.query(
      'INSERT INTO orders (reference, client_nom, client_email, client_tel, client_adresse, total, payment_method, payment_id) VALUES (?,?,?,?,?,?,?,?)',
      [ref, client.nom, client.email, client.tel, client.adresse, total, payment_method, payment_id]
    );
    for (const item of items) {
      await conn.query(
        'INSERT INTO order_items (order_id, product_id, variant_id, nom_produit, quantite, prix_unitaire) VALUES (?,?,?,?,?,?)',
        [order.insertId, item.product_id, item.variant_id || null, item.nom_produit, item.quantite, item.prix_unitaire]
      );
      await conn.query('UPDATE products SET stock = stock - ? WHERE id = ?', [item.quantite, item.product_id]);
    }
    await conn.commit();
    conn.release();
    await sendOrderConfirmation({ reference: ref, email: client.email, nom: client.nom, items, total });
    res.json({ success: true, reference: ref, order_id: order.insertId });
  } catch (e) {
    await conn.rollback();
    conn.release();
    res.status(500).json({ error: e.message });
  }
};

exports.getAll = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM orders ORDER BY created_at DESC');
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.getOne = async (req, res) => {
  try {
    const [order] = await db.query('SELECT * FROM orders WHERE id = ?', [req.params.id]);
    if (!order.length) return res.status(404).json({ error: 'Commande introuvable' });
    const [items] = await db.query('SELECT * FROM order_items WHERE order_id = ?', [req.params.id]);
    res.json({ ...order[0], items });
  } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.updateStatus = async (req, res) => {
  try {
    await db.query('UPDATE orders SET statut = ? WHERE id = ?', [req.body.statut, req.params.id]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
};
