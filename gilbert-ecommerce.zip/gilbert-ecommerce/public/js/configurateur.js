(function () {
  const canvas = document.getElementById('cachet-preview');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const SIZE = 300;
  canvas.width = SIZE;
  canvas.height = SIZE;
  const state = { diametre: '30', texteHaut: '', texteBas: '', logo: null };

  function drawTextArc(text, radius, startAngle, direction) {
    if (!text) return;
    ctx.save();
    ctx.font = 'bold 13px serif';
    ctx.fillStyle = '#1a1a2e';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const chars = text.toUpperCase().split('');
    const totalAngle = Math.min(Math.PI * 1.2, (chars.length * 14) / radius);
    const angleStep = totalAngle / Math.max(chars.length - 1, 1);
    const angleStart = startAngle - (totalAngle / 2);
    chars.forEach((char, i) => {
      const angle = angleStart + i * angleStep;
      const x = SIZE / 2 + radius * Math.cos(angle);
      const y = SIZE / 2 + radius * Math.sin(angle);
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(angle + (direction === 1 ? Math.PI / 2 : -Math.PI / 2));
      ctx.fillText(char, 0, 0);
      ctx.restore();
    });
    ctx.restore();
  }

  function draw() {
    ctx.clearRect(0, 0, SIZE, SIZE);
    const R = state.diametre === '30' ? 120 : 100;
    const cx = SIZE / 2, cy = SIZE / 2;
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.fillStyle = '#f5f0e8'; ctx.fill();
    ctx.strokeStyle = '#8b6914'; ctx.lineWidth = 3; ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, R - 18, 0, Math.PI * 2);
    ctx.strokeStyle = '#8b6914'; ctx.lineWidth = 1.5; ctx.stroke();
    drawTextArc(state.texteHaut, R - 10, -Math.PI / 2, 1);
    drawTextArc(state.texteBas, R - 10, Math.PI / 2, -1);
    if (state.logo) {
      const img = new Image();
      img.onload = () => {
        const maxSize = (R - 24) * 1.4;
        const ratio = Math.min(maxSize / img.width, maxSize / img.height);
        ctx.drawImage(img, cx - img.width * ratio / 2, cy - img.height * ratio / 2, img.width * ratio, img.height * ratio);
      };
      img.src = state.logo;
    } else {
      ctx.fillStyle = '#c9a84c'; ctx.font = '11px sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('Votre logo', cx, cy - 8); ctx.fillText('ici', cx, cy + 8);
    }
    ctx.fillStyle = '#8b691455'; ctx.font = '10px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
    ctx.fillText('Ø ' + state.diametre + ' mm', cx, SIZE - 6);
  }

  ['texteHaut', 'texteBas', 'diametre'].forEach(key => {
    const el = document.getElementById(key);
    if (el) el.addEventListener('input', () => { state[key] = el.value; draw(); });
  });
  const logoInput = document.getElementById('logoInput');
  if (logoInput) logoInput.addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => { state.logo = ev.target.result; draw(); };
    reader.readAsDataURL(file);
  });
  draw();
})();
